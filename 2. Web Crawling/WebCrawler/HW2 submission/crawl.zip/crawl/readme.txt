Name : Ashwin Chafale
USC ID : 1990624801
Assigned Search Engine : https://www.nytimes.com/
Homework Completed with SE : https://wsj.com/  -- as per piazza post https://piazza.com/class/lcqmeu0u2er5e2/post/414

Total number of URL fetches attempted by web crawler is 19996 out of 20000. This is because web-crawler wasn't
able to visit few URLs on USC secured Wi-Fi.

Crawler code in : /src folder
Used python to calculate statistics on csv files.
Python code : /python
